# Financial App - React Native

A beautiful, intuitive, and intelligent financial management application built with React Native and TypeScript.

## Features

- **Home Page with Due Bills**: View upcoming bills in a clean, modern layout with paycheck/month toggle
- **Month View**: Group bills by paycheck with monthly summary statistics
- **Bill Management**: Add, edit, pay, and reschedule bills with intuitive interactions
- **Paycheck Tracking**: Manage income sources and associate bills with specific paychecks
- **Budget Management**: Create and monitor budgets with visual progress indicators
- **Debt Repayment**: Track debts with payoff projections and strategy selection (avalanche/snowball)
- **Goals Tracking**: Set and monitor financial goals with progress visualization
- **Notifications**: Get reminders for due bills with snooze options
- **Settings**: Customize app appearance and behavior
- **Payment History**: Track bill payments with filtering options
- **Financial Dashboard**: Get insights into your financial health with visualizations
- **Dark Mode Support**: Toggle between light and dark themes

## Tech Stack

- React Native
- TypeScript
- Redux Toolkit for state management
- React Navigation for routing
- React Native Paper for UI components
- Victory Native for data visualization
- date-fns for date handling
- Formik and Yup for form handling and validation

## Project Structure

```
src/
├── assets/         # Images, fonts, and other static assets
├── components/     # Reusable UI components
│   ├── Card/       # Card components for bills, paychecks, etc.
│   ├── Form/       # Form input components
│   ├── List/       # List item components
│   ├── Modal/      # Modal and bottom sheet components
│   ├── Progress/   # Progress indicators
│   └── EmptyState/ # Empty state components
├── hooks/          # Custom React hooks
├── navigation/     # Navigation configuration
├── screens/        # App screens
│   ├── Bill/       # Bill-related screens
│   ├── Budget/     # Budget-related screens
│   ├── Dashboard/  # Dashboard screen
│   ├── Debt/       # Debt-related screens
│   ├── Goals/      # Goals-related screens
│   ├── Home/       # Home screen
│   ├── Month/      # Month view screen
│   ├── Notifications/ # Notifications screen
│   ├── Paychecks/  # Paycheck-related screens
│   ├── Payment/    # Payment history screen
│   ├── Performance/ # Performance screen
│   ├── Settings/   # Settings-related screens
│   └── Test/       # Test screen
├── store/          # Redux store configuration
│   └── slices/     # Redux slices for state management
├── theme/          # Theme configuration
├── types/          # TypeScript type definitions
└── utils/          # Utility functions
```

## Getting Started

### Prerequisites

- Node.js (v14 or later)
- npm or yarn
- React Native development environment set up

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
   or
   ```
   yarn install
   ```
3. Start the development server:
   ```
   npm start
   ```
   or
   ```
   yarn start
   ```
4. Run on iOS or Android:
   ```
   npm run ios
   ```
   or
   ```
   npm run android
   ```

## Usage

### Home Screen

The home screen displays your upcoming bills grouped by paycheck or by month. You can toggle between these views using the pills at the top of the screen. Each bill shows its name, amount, due date, and payment status.

### Adding a Bill

Tap the "+" button on the home screen to add a new bill. Fill in the bill details including name, amount, due date, category, and whether it's recurring.

### Managing Bills

Long press on a bill to see options like "Edit", "Pay Now", or "Pay Later". Tapping "Pay Later" will reschedule the bill to the next paycheck.

### Paychecks

The Paychecks tab allows you to manage your income sources. You can add new paychecks, view upcoming paychecks, and see which bills are associated with each paycheck.

### Budget

The Budget tab helps you track your spending by category. You can create budget categories, set limits, and monitor your progress with visual indicators.

### Debt Repayment

The Debt Repayment tab helps you track your debts and plan your payoff strategy. You can choose between the Avalanche method (highest interest first) or the Snowball method (smallest balance first).

### Goals

The Goals tab allows you to set and track financial goals like saving for an emergency fund, vacation, or major purchase. Each goal shows your progress and estimated completion date.

### Settings

The Settings screen allows you to customize the app to your preferences. You can toggle dark mode, set notification preferences, and manage other app settings.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [React Native](https://reactnative.dev/)
- [React Navigation](https://reactnavigation.org/)
- [React Native Paper](https://callstack.github.io/react-native-paper/)
- [Redux Toolkit](https://redux-toolkit.js.org/)
- [Victory Native](https://formidable.com/open-source/victory/docs/native/)
