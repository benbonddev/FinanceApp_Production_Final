import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../index';
import { Paycheck } from '../../types';
import { saveData, loadData, STORAGE_KEYS } from '../../utils/storage';
import { isAfter, parseISO, compareAsc } from 'date-fns';

// Sample paychecks for development
const initialPaychecks: Paycheck[] = [
  {
    id: '1',
    name: 'Main Job',
    amount: 2500,
    date: new Date(2025, 3, 15).toISOString(),
    owner: 'John Doe',
    isRecurring: true,
    recurringFrequency: 'biweekly',
  },
  {
    id: '2',
    name: 'Side Gig',
    amount: 500,
    date: new Date(2025, 3, 20).toISOString(),
    owner: 'John Doe',
    isRecurring: false,
  },
  {
    id: '3',
    name: 'Main Job',
    amount: 2500,
    date: new Date(2025, 3, 29).toISOString(),
    owner: 'John Doe',
    isRecurring: true,
    recurringFrequency: 'biweekly',
  },
  {
    id: '4',
    name: 'Rental Income',
    amount: 1200,
    date: new Date(2025, 3, 5).toISOString(),
    owner: 'John Doe',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
];

interface PaychecksState {
  paychecks: Paycheck[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: PaychecksState = {
  paychecks: [],
  status: 'idle',
  error: null,
};

export const paychecksSlice = createSlice({
  name: 'paychecks',
  initialState,
  reducers: {
    setPaychecks: (state, action: PayloadAction<Paycheck[]>) => {
      state.paychecks = action.payload;
      state.status = 'succeeded';
      // Persist to storage
      saveData(STORAGE_KEYS.PAYCHECKS, action.payload);
    },
    addPaycheck: (state, action: PayloadAction<Paycheck>) => {
      state.paychecks.push(action.payload);
      // Persist to storage
      saveData(STORAGE_KEYS.PAYCHECKS, state.paychecks);
    },
    updatePaycheck: (state, action: PayloadAction<Paycheck>) => {
      const index = state.paychecks.findIndex(paycheck => paycheck.id === action.payload.id);
      if (index !== -1) {
        state.paychecks[index] = action.payload;
        // Persist to storage
        saveData(STORAGE_KEYS.PAYCHECKS, state.paychecks);
      }
    },
    deletePaycheck: (state, action: PayloadAction<string>) => {
      state.paychecks = state.paychecks.filter(paycheck => paycheck.id !== action.payload);
      // Persist to storage
      saveData(STORAGE_KEYS.PAYCHECKS, state.paychecks);
    },
    loadSamplePaychecks: (state) => {
      state.paychecks = initialPaychecks;
      state.status = 'succeeded';
      // Persist to storage
      saveData(STORAGE_KEYS.PAYCHECKS, initialPaychecks);
    },
    loadPaychecksFromStorage: (state) => {
      state.status = 'loading';
    },
    loadPaychecksSuccess: (state, action: PayloadAction<Paycheck[]>) => {
      state.paychecks = action.payload;
      state.status = 'succeeded';
    },
    loadPaychecksFailure: (state, action: PayloadAction<string>) => {
      state.error = action.payload;
      state.status = 'failed';
    },
  },
});

export const { 
  setPaychecks, 
  addPaycheck, 
  updatePaycheck, 
  deletePaycheck, 
  loadSamplePaychecks,
  loadPaychecksFromStorage,
  loadPaychecksSuccess,
  loadPaychecksFailure
} = paychecksSlice.actions;

// Thunk to load paychecks from storage
export const loadPaychecksAsync = () => async (dispatch: any) => {
  dispatch(loadPaychecksFromStorage());
  try {
    const paychecks = await loadData<Paycheck[]>(STORAGE_KEYS.PAYCHECKS, []);
    dispatch(loadPaychecksSuccess(paychecks && paychecks.length > 0 ? paychecks : initialPaychecks));
  } catch (error) {
    dispatch(loadPaychecksFailure(error instanceof Error ? error.message : 'Unknown error'));
    dispatch(loadPaychecksSuccess(initialPaychecks)); // Fallback to sample data
  }
};

// Selectors with proper null safety
export const selectAllPaychecks = (state: RootState) => state.paychecks.paychecks || [];
export const selectPaycheckById = (state: RootState, paycheckId: string | undefined) => 
  paycheckId ? state.paychecks.paychecks.find(paycheck => paycheck.id === paycheckId) : undefined;
export const selectPaychecksStatus = (state: RootState) => state.paychecks.status;
export const selectPaychecksError = (state: RootState) => state.paychecks.error;

// Selector for next paycheck with proper error handling
export const selectNextPaycheck = (state: RootState) => {
  const today = new Date();
  
  // Filter paychecks that are in the future with proper null safety
  const futurePaychecks = (state.paychecks.paychecks || []).filter(paycheck => {
    if (!paycheck || !paycheck.date) return false;
    try {
      const paycheckDate = parseISO(paycheck.date);
      return isAfter(paycheckDate, today);
    } catch (error) {
      return false;
    }
  });
  
  // Sort by date (ascending) with error handling
  const sortedPaychecks = [...futurePaychecks].sort((a, b) => {
    try {
      return compareAsc(parseISO(a.date), parseISO(b.date));
    } catch (error) {
      return 0;
    }
  });
  
  // Return the first one (closest to today)
  return sortedPaychecks.length > 0 ? sortedPaychecks[0] : null;
};

// Selector for paychecks by month
export const selectPaychecksByMonth = (state: RootState, month: string | undefined) => {
  if (!month) return [];
  
  return (state.paychecks.paychecks || []).filter(paycheck => {
    if (!paycheck || !paycheck.date) return false;
    try {
      const paycheckDate = parseISO(paycheck.date);
      const paycheckMonth = paycheckDate.getFullYear() + '-' + 
        (paycheckDate.getMonth() + 1).toString().padStart(2, '0');
      return paycheckMonth === month;
    } catch (error) {
      return false;
    }
  });
};

export default paychecksSlice.reducer;
