import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import NavigationAnalysisScreen from '../screens/Test/NavigationAnalysisScreen';
import TestScreen from '../screens/Test/TestScreen';
import ChartTest from '../screens/Test/ChartTest';
import PerformanceScreen from '../screens/Performance/PerformanceScreen';

const Stack = createStackNavigator();

const TestNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="TestScreen"
      screenOptions={{
        headerShown: true,
      }}
    >
      <Stack.Screen 
        name="TestScreen" 
        component={TestScreen} 
        options={{ title: 'Test Results' }}
      />
      <Stack.Screen 
        name="NavigationAnalysis" 
        component={NavigationAnalysisScreen} 
        options={{ title: 'Navigation Analysis' }}
      />
      <Stack.Screen 
        name="PerformanceScreen" 
        component={PerformanceScreen} 
        options={{ title: 'Performance' }}
      />
      <Stack.Screen 
        name="ChartTest" 
        component={ChartTest} 
        options={{ title: 'Chart Visualizations' }}
      />
    </Stack.Navigator>
  );
};

export default TestNavigator;
