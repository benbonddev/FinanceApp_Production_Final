import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import GoalsScreen from '../screens/Goals/GoalsScreen';
import AddGoalScreen from '../screens/Goals/AddGoalScreen';

const Stack = createStackNavigator();

const GoalsNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="GoalsScreen"
      screenOptions={{
        headerShown: true,
      }}
    >
      <Stack.Screen 
        name="GoalsScreen" 
        component={GoalsScreen} 
        options={{ title: 'Financial Goals' }}
      />
      <Stack.Screen 
        name="AddGoal" 
        component={AddGoalScreen} 
        options={{ title: 'Add Goal' }}
      />
    </Stack.Navigator>
  );
};

export default GoalsNavigator;
