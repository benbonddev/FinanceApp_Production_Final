import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, Dimensions } from 'react-native';
import { Text, useTheme, Card, Button, Divider, IconButton } from 'react-native-paper';
import { useAppSelector, useAppDispatch } from '../../hooks/reduxHooks';
import { selectAllBills } from '../../store/slices/billsSlice';
import { selectAllPaychecks } from '../../store/slices/paychecksSlice';
import { VictoryPie, VictoryBar, VictoryChart, VictoryAxis, VictoryTheme, VictoryLine } from 'victory-native';
import CircularProgress from '../../components/Progress/CircularProgress';
import LinearProgress from '../../components/Progress/LinearProgress';
import { format, parseISO, startOfMonth, endOfMonth, subMonths, addMonths } from 'date-fns';

const { width } = Dimensions.get('window');
const chartWidth = width - 48;

const DashboardScreen: React.FC = () => {
  const theme = useTheme();
  const bills = useAppSelector(selectAllBills);
  const paychecks = useAppSelector(selectAllPaychecks);
  
  // Calculate current month's financial health
  const currentMonth = new Date();
  const totalIncome = paychecks
    .filter(paycheck => {
      const date = parseISO(paycheck.date);
      return date.getMonth() === currentMonth.getMonth() && 
             date.getFullYear() === currentMonth.getFullYear();
    })
    .reduce((sum, paycheck) => sum + paycheck.amount, 0);
  
  const totalExpenses = bills
    .filter(bill => {
      const date = parseISO(bill.dueDate);
      return date.getMonth() === currentMonth.getMonth() && 
             date.getFullYear() === currentMonth.getFullYear();
    })
    .reduce((sum, bill) => sum + bill.amount, 0);
  
  const savingsRate = totalIncome > 0 ? (totalIncome - totalExpenses) / totalIncome : 0;
  
  // Calculate bill payment rate
  const monthBills = bills.filter(bill => {
    const date = parseISO(bill.dueDate);
    return date.getMonth() === currentMonth.getMonth() && 
           date.getFullYear() === currentMonth.getFullYear();
  });
  
  const paidBills = monthBills.filter(bill => bill.isPaid);
  const billPaymentRate = monthBills.length > 0 ? paidBills.length / monthBills.length : 0;
  
  // Prepare expense by category data
  const expensesByCategory = bills.reduce((acc, bill) => {
    if (!bill.category) return acc;
    
    if (!acc[bill.category]) {
      acc[bill.category] = 0;
    }
    
    acc[bill.category] += bill.amount;
    return acc;
  }, {} as Record<string, number>);
  
  const categoryData = Object.entries(expensesByCategory).map(([category, amount]) => ({
    x: category,
    y: amount,
  }));
  
  // Prepare income vs expenses data for last 6 months
  const months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(currentMonth, 5 - i);
    return {
      date,
      label: format(date, 'MMM'),
      income: 0,
      expenses: 0,
    };
  });
  
  // Calculate income for each month
  paychecks.forEach(paycheck => {
    const date = parseISO(paycheck.date);
    const monthIndex = months.findIndex(m => 
      m.date.getMonth() === date.getMonth() && 
      m.date.getFullYear() === date.getFullYear()
    );
    
    if (monthIndex !== -1) {
      months[monthIndex].income += paycheck.amount;
    }
  });
  
  // Calculate expenses for each month
  bills.forEach(bill => {
    const date = parseISO(bill.dueDate);
    const monthIndex = months.findIndex(m => 
      m.date.getMonth() === date.getMonth() && 
      m.date.getFullYear() === date.getFullYear()
    );
    
    if (monthIndex !== -1) {
      months[monthIndex].expenses += bill.amount;
    }
  });
  
  const incomeData = months.map((month, index) => ({
    x: index + 1,
    y: month.income,
    label: month.label,
  }));
  
  const expensesData = months.map((month, index) => ({
    x: index + 1,
    y: month.expenses,
    label: month.label,
  }));
  
  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Financial Dashboard</Text>
        <Text style={styles.subtitle}>{format(currentMonth, 'MMMM yyyy')}</Text>
      </View>
      
      <View style={styles.summaryCards}>
        <Card style={[styles.summaryCard, { backgroundColor: theme.colors.surface }]}>
          <Card.Content>
            <Text style={styles.cardTitle}>Monthly Income</Text>
            <Text style={[styles.cardValue, { color: theme.colors.success }]}>
              ${totalIncome.toFixed(2)}
            </Text>
          </Card.Content>
        </Card>
        
        <Card style={[styles.summaryCard, { backgroundColor: theme.colors.surface }]}>
          <Card.Content>
            <Text style={styles.cardTitle}>Monthly Expenses</Text>
            <Text style={[styles.cardValue, { color: theme.colors.error }]}>
              ${totalExpenses.toFixed(2)}
            </Text>
          </Card.Content>
        </Card>
      </View>
      
      <Card style={[styles.insightCard, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text style={styles.insightTitle}>Financial Health</Text>
          
          <View style={styles.metricsContainer}>
            <View style={styles.metricItem}>
              <CircularProgress
                progress={Math.max(0, Math.min(savingsRate, 1))}
                size={80}
                strokeWidth={8}
                color={savingsRate >= 0.2 ? theme.colors.success : 
                       savingsRate >= 0.1 ? theme.colors.warning : 
                       theme.colors.error}
              >
                <Text style={styles.metricValue}>
                  {Math.round(savingsRate * 100)}%
                </Text>
              </CircularProgress>
              <Text style={styles.metricLabel}>Savings Rate</Text>
              <Text style={styles.metricDescription}>
                {savingsRate >= 0.2 ? 'Excellent' : 
                 savingsRate >= 0.1 ? 'Good' : 
                 'Needs Improvement'}
              </Text>
            </View>
            
            <View style={styles.metricItem}>
              <CircularProgress
                progress={billPaymentRate}
                size={80}
                strokeWidth={8}
                color={billPaymentRate >= 0.9 ? theme.colors.success : 
                       billPaymentRate >= 0.7 ? theme.colors.warning : 
                       theme.colors.error}
              >
                <Text style={styles.metricValue}>
                  {Math.round(billPaymentRate * 100)}%
                </Text>
              </CircularProgress>
              <Text style={styles.metricLabel}>Bill Payment</Text>
              <Text style={styles.metricDescription}>
                {billPaymentRate >= 0.9 ? 'On Track' : 
                 billPaymentRate >= 0.7 ? 'Almost There' : 
                 'Falling Behind'}
              </Text>
            </View>
          </View>
          
          <View style={styles.balanceContainer}>
            <Text style={styles.balanceLabel}>Monthly Balance</Text>
            <Text style={[
              styles.balanceValue, 
              { color: totalIncome - totalExpenses >= 0 ? theme.colors.success : theme.colors.error }
            ]}>
              ${Math.abs(totalIncome - totalExpenses).toFixed(2)}
              {totalIncome - totalExpenses >= 0 ? ' Surplus' : ' Deficit'}
            </Text>
            <LinearProgress
              progress={Math.min(totalExpenses / (totalIncome || 1), 1.5)}
              height={8}
              color={totalExpenses <= totalIncome ? theme.colors.success : theme.colors.error}
            />
          </View>
        </Card.Content>
      </Card>
      
      <Card style={[styles.chartCard, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text style={styles.chartTitle}>Expenses by Category</Text>
          
          {categoryData.length > 0 ? (
            <View style={styles.pieChartContainer}>
              <VictoryPie
                data={categoryData}
                width={chartWidth}
                height={200}
                colorScale={[
                  theme.colors.primary,
                  theme.colors.accent,
                  theme.colors.notification,
                  theme.colors.success,
                  theme.colors.warning,
                  theme.colors.error,
                ]}
                innerRadius={40}
                labelRadius={90}
                style={{ labels: { fill: theme.colors.text, fontSize: 12 } }}
                animate={{ duration: 500 }}
              />
            </View>
          ) : (
            <Text style={styles.noDataText}>No expense data available</Text>
          )}
        </Card.Content>
      </Card>
      
      <Card style={[styles.chartCard, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text style={styles.chartTitle}>Income vs Expenses (6 Months)</Text>
          
          <VictoryChart
            width={chartWidth}
            height={250}
            theme={VictoryTheme.material}
            domainPadding={{ x: 20 }}
          >
            <VictoryAxis
              tickValues={[1, 2, 3, 4, 5, 6]}
              tickFormat={months.map(m => m.label)}
              style={{
                axis: { stroke: theme.colors.text },
                tickLabels: { fill: theme.colors.text, fontSize: 10 },
              }}
            />
            <VictoryAxis
              dependentAxis
              style={{
                axis: { stroke: theme.colors.text },
                tickLabels: { fill: theme.colors.text, fontSize: 10 },
              }}
            />
            <VictoryLine
              data={incomeData}
              style={{
                data: { stroke: theme.colors.success, strokeWidth: 2 },
              }}
              animate={{ duration: 500 }}
            />
            <VictoryLine
              data={expensesData}
              style={{
                data: { stroke: theme.colors.error, strokeWidth: 2 },
              }}
              animate={{ duration: 500 }}
            />
          </VictoryChart>
          
          <View style={styles.legendContainer}>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: theme.colors.success }]} />
              <Text style={styles.legendText}>Income</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: theme.colors.error }]} />
              <Text style={styles.legendText}>Expenses</Text>
            </View>
          </View>
        </Card.Content>
      </Card>
      
      <Card style={[styles.insightCard, { backgroundColor: theme.colors.surface }]}>
        <Card.Content>
          <Text style={styles.insightTitle}>Financial Insights</Text>
          
          <View style={styles.insightItem}>
            <IconButton
              icon="trending-up"
              size={24}
              color={theme.colors.primary}
              style={styles.insightIcon}
            />
            <View style={styles.insightContent}>
              <Text style={styles.insightText}>
                {totalIncome > totalExpenses 
                  ? `You're saving ${Math.round(savingsRate * 100)}% of your income this month.`
                  : "You're spending more than you earn this month."}
              </Text>
              <Text style={styles.insightAction}>
                {totalIncome > totalExpenses 
                  ? "Consider allocating more to savings or debt repayment."
                  : "Look for expenses you can reduce to balance your budget."}
              </Text>
            </View>
          </View>
          
          <Divider style={styles.divider} />
          
          <View style={styles.insightItem}>
            <IconButton
              icon="calendar-check"
              size={24}
              color={theme.colors.primary}
              style={styles.insightIcon}
            />
            <View style={styles.insightContent}>
              <Text style={styles.insightText}>
                {billPaymentRate >= 0.9 
                  ? "You've paid most of your bills on time this month."
                  : `You still have ${monthBills.length - paidBills.length} unpaid bills this month.`}
              </Text>
              <Text style={styles.insightAction}>
                {billPaymentRate >= 0.9 
                  ? "Great job staying on top of your finances!"
                  : "Check your upcoming bills to avoid late fees."}
              </Text>
            </View>
          </View>
          
          <Divider style={styles.divider} />
          
          <View style={styles.insightItem}>
            <IconButton
              icon="chart-line"
              size={24}
              color={theme.colors.primary}
              style={styles.insightIcon}
            />
            <View style={styles.insightContent}>
              <Text style={styles.insightText}>
                {months[5].income > months[0].income 
                  ? "Your income has increased over the past 6 months."
                  : months[5].income < months[0].income 
                    ? "Your income has decreased over the past 6 months."
                    : "Your income has remained stable over the past 6 months."}
              </Text>
              <Text style={styles.insightAction}>
                {months[5].expenses > months[0].expenses 
                  ? "Your expenses have also increased. Monitor this trend."
                  : "Keep managing your expenses well to improve savings."}
              </Text>
            </View>
          </View>
        </Card.Content>
      </Card>
      
      <View style={styles.footer}>
        <Button
          mode="contained"
          onPress={() => console.log('Navigate to detailed reports')}
          style={styles.footerButton}
        >
          View Detailed Reports
        </Button>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    opacity: 0.7,
  },
  summaryCards: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  summaryCard: {
    flex: 1,
    marginHorizontal: 4,
  },
  cardTitle: {
    fontSize: 14,
    opacity: 0.7,
  },
  cardValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 4,
  },
  insightCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  insightTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  metricItem: {
    alignItems: 'center',
  },
  metricValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  metricLabel: {
    fontSize: 14,
    marginTop: 8,
  },
  metricDescription: {
    fontSize: 12,
    opacity: 0.7,
    marginTop: 4,
  },
  balanceContainer: {
    marginTop: 16,
  },
  balanceLabel: {
    fontSize: 14,
    opacity: 0.7,
  },
  balanceValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 4,
  },
  chartCard: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  pieChartContainer: {
    alignItems: 'center',
  },
  noDataText: {
    textAlign: 'center',
    opacity: 0.7,
    padding: 20,
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 8,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 4,
  },
  legendText: {
    fontSize: 12,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  insightIcon: {
    margin: 0,
  },
  insightContent: {
    flex: 1,
  },
  insightText: {
    fontSize: 14,
  },
  insightAction: {
    fontSize: 12,
    opacity: 0.7,
    marginTop: 4,
  },
  divider: {
    marginVertical: 8,
  },
  footer: {
    padding: 16,
  },
  footerButton: {
    marginBottom: 16,
  },
});

export default DashboardScreen;
