import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, FlatList } from 'react-native';
import { Text, useTheme, FAB, Divider, IconButton, Button, Chip } from 'react-native-paper';
import { useAppSelector, useAppDispatch } from '../../hooks/reduxHooks';
import { selectAllBills } from '../../store/slices/billsSlice';
import { selectAllPaychecks } from '../../store/slices/paychecksSlice';
import ListItem from '../../components/List/ListItem';
import EmptyState from '../../components/EmptyState/EmptyState';
import CircularProgress from '../../components/Progress/CircularProgress';
import { Bill } from '../../types';
import { format, parseISO, startOfMonth, endOfMonth, isSameMonth } from 'date-fns';

const PaymentHistoryScreen: React.FC = () => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  const [filter, setFilter] = useState<'all' | 'paid' | 'unpaid'>('all');
  
  const bills = useAppSelector(selectAllBills);
  const paychecks = useAppSelector(selectAllPaychecks);
  
  // Filter bills for the selected month
  const monthBills = bills.filter(bill => {
    const billDate = parseISO(bill.dueDate);
    return isSameMonth(billDate, selectedMonth);
  });
  
  // Apply additional filtering
  const filteredBills = monthBills.filter(bill => {
    if (filter === 'all') return true;
    if (filter === 'paid') return bill.isPaid;
    if (filter === 'unpaid') return !bill.isPaid;
    return true;
  });
  
  // Sort bills by due date
  filteredBills.sort((a, b) => {
    return parseISO(a.dueDate).getTime() - parseISO(b.dueDate).getTime();
  });
  
  // Calculate monthly statistics
  const totalBills = monthBills.length;
  const paidBills = monthBills.filter(bill => bill.isPaid).length;
  const paidAmount = monthBills
    .filter(bill => bill.isPaid)
    .reduce((sum, bill) => sum + bill.amount, 0);
  const unpaidAmount = monthBills
    .filter(bill => !bill.isPaid)
    .reduce((sum, bill) => sum + bill.amount, 0);
  const paymentProgress = totalBills > 0 ? paidBills / totalBills : 0;
  
  // Handle month navigation
  const navigateMonth = (direction: 'prev' | 'next') => {
    const newMonth = new Date(selectedMonth);
    if (direction === 'prev') {
      newMonth.setMonth(newMonth.getMonth() - 1);
    } else {
      newMonth.setMonth(newMonth.getMonth() + 1);
    }
    setSelectedMonth(newMonth);
  };
  
  // Handle bill press
  const handleBillPress = (bill: Bill) => {
    console.log('Bill pressed:', bill.id);
    // Navigate to bill detail or show bottom sheet
  };
  
  // Render payment history item
  const renderPaymentItem = (bill: Bill) => {
    const dueDate = parseISO(bill.dueDate);
    const paidDate = bill.paidDate ? parseISO(bill.paidDate) : null;
    
    return (
      <ListItem
        key={bill.id}
        title={bill.name}
        description={`Due: ${format(dueDate, 'MMM d, yyyy')}`}
        leftIcon={
          <View style={[
            styles.statusIndicator, 
            { 
              backgroundColor: bill.isPaid 
                ? theme.colors.success 
                : new Date() > dueDate 
                  ? theme.colors.error 
                  : theme.colors.warning 
            }
          ]} />
        }
        rightContent={
          <View style={styles.paymentInfo}>
            <Text style={styles.paymentAmount}>${bill.amount.toFixed(2)}</Text>
            <Text style={[
              styles.paymentStatus, 
              { 
                color: bill.isPaid 
                  ? theme.colors.success 
                  : new Date() > dueDate 
                    ? theme.colors.error 
                    : theme.colors.warning 
              }
            ]}>
              {bill.isPaid 
                ? `Paid ${paidDate ? format(paidDate, 'MMM d') : ''}` 
                : new Date() > dueDate 
                  ? 'Overdue' 
                  : 'Upcoming'}
            </Text>
          </View>
        }
        onPress={() => handleBillPress(bill)}
        containerStyle={styles.listItem}
      />
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.monthNavigation}>
        <IconButton
          icon="chevron-left"
          size={24}
          onPress={() => navigateMonth('prev')}
        />
        <Text style={styles.monthTitle}>{format(selectedMonth, 'MMMM yyyy')}</Text>
        <IconButton
          icon="chevron-right"
          size={24}
          onPress={() => navigateMonth('next')}
        />
      </View>
      
      <View style={[styles.summaryCard, { backgroundColor: theme.colors.surface }]}>
        <View style={styles.progressContainer}>
          <CircularProgress
            progress={paymentProgress}
            size={80}
            strokeWidth={8}
            color={theme.colors.primary}
          >
            <Text style={styles.progressPercentage}>
              {Math.round(paymentProgress * 100)}%
            </Text>
          </CircularProgress>
          
          <View style={styles.summaryDetails}>
            <Text style={styles.summaryTitle}>Payment Progress</Text>
            <Text style={styles.summarySubtitle}>
              {paidBills} of {totalBills} bills paid
            </Text>
            
            <View style={styles.amountContainer}>
              <View style={styles.amountItem}>
                <Text style={styles.amountLabel}>Paid</Text>
                <Text style={[styles.amountValue, { color: theme.colors.success }]}>
                  ${paidAmount.toFixed(2)}
                </Text>
              </View>
              
              <View style={styles.amountItem}>
                <Text style={styles.amountLabel}>Unpaid</Text>
                <Text style={[styles.amountValue, { color: theme.colors.error }]}>
                  ${unpaidAmount.toFixed(2)}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </View>
      
      <View style={styles.filterContainer}>
        <Chip
          selected={filter === 'all'}
          onPress={() => setFilter('all')}
          style={styles.filterChip}
        >
          All
        </Chip>
        <Chip
          selected={filter === 'paid'}
          onPress={() => setFilter('paid')}
          style={styles.filterChip}
        >
          Paid
        </Chip>
        <Chip
          selected={filter === 'unpaid'}
          onPress={() => setFilter('unpaid')}
          style={styles.filterChip}
        >
          Unpaid
        </Chip>
      </View>
      
      <Text style={styles.sectionTitle}>Payment History</Text>
      
      {filteredBills.length > 0 ? (
        <FlatList
          data={filteredBills}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => renderPaymentItem(item)}
          contentContainerStyle={styles.listContent}
        />
      ) : (
        <EmptyState
          icon="cash-multiple"
          title="No Payments Found"
          description={`No ${filter !== 'all' ? filter + ' ' : ''}bills found for this month.`}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  monthNavigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  monthTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  summaryCard: {
    margin: 16,
    padding: 16,
    borderRadius: 8,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressPercentage: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  summaryDetails: {
    flex: 1,
    marginLeft: 16,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  summarySubtitle: {
    fontSize: 14,
    opacity: 0.7,
    marginBottom: 8,
  },
  amountContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  amountItem: {
    flex: 1,
  },
  amountLabel: {
    fontSize: 12,
    opacity: 0.7,
  },
  amountValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  filterChip: {
    marginRight: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  listContent: {
    paddingHorizontal: 16,
  },
  listItem: {
    marginBottom: 8,
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  paymentInfo: {
    alignItems: 'flex-end',
  },
  paymentAmount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  paymentStatus: {
    fontSize: 12,
  },
});

export default PaymentHistoryScreen;
