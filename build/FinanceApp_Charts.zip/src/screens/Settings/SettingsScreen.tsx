import React, { useState } from 'react';
import { StyleSheet, View, ScrollView, Switch } from 'react-native';
import { Text, useTheme, Divider, List, IconButton } from 'react-native-paper';
import { useAppSelector, useAppDispatch } from '../../hooks/reduxHooks';
import { toggleTheme } from '../../store/slices/themeSlice';
import ListItem from '../../components/List/ListItem';
import Modal from '../../components/Modal/Modal';

const SettingsScreen: React.FC = () => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  const isDarkMode = useAppSelector(state => state.theme.isDarkMode);
  
  // Notification settings
  const [notificationLevel, setNotificationLevel] = useState<'normal' | 'aggressive'>('normal');
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  
  // App settings
  const [defaultView, setDefaultView] = useState<'paycheck' | 'month'>('paycheck');
  const [showDefaultViewModal, setShowDefaultViewModal] = useState(false);
  
  // Handle theme toggle
  const handleThemeToggle = () => {
    dispatch(toggleTheme());
  };
  
  // Handle notification level change
  const handleNotificationLevelChange = (level: 'normal' | 'aggressive') => {
    setNotificationLevel(level);
    setShowNotificationModal(false);
  };
  
  // Handle default view change
  const handleDefaultViewChange = (view: 'paycheck' | 'month') => {
    setDefaultView(view);
    setShowDefaultViewModal(false);
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Appearance</Text>
          <ListItem
            title="Dark Mode"
            rightContent={
              <Switch
                value={isDarkMode}
                onValueChange={handleThemeToggle}
                color={theme.colors.primary}
              />
            }
          />
        </View>
        
        <Divider style={styles.divider} />
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Notifications</Text>
          <ListItem
            title="Notification Level"
            description={notificationLevel === 'normal' ? 'Standard reminders' : 'Frequent reminders'}
            rightContent={
              <Text style={{ color: theme.colors.primary }}>
                {notificationLevel === 'normal' ? 'Normal' : 'Aggressive'}
              </Text>
            }
            onPress={() => setShowNotificationModal(true)}
          />
          <ListItem
            title="Bill Due Reminders"
            description="Notify when bills are due"
            rightContent={
              <Switch
                value={true}
                onValueChange={() => {}}
                color={theme.colors.primary}
              />
            }
          />
          <ListItem
            title="Payment Confirmation"
            description="Notify after bill payment"
            rightContent={
              <Switch
                value={true}
                onValueChange={() => {}}
                color={theme.colors.primary}
              />
            }
          />
          <ListItem
            title="Budget Alerts"
            description="Notify when approaching budget limits"
            rightContent={
              <Switch
                value={true}
                onValueChange={() => {}}
                color={theme.colors.primary}
              />
            }
          />
        </View>
        
        <Divider style={styles.divider} />
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>App Settings</Text>
          <ListItem
            title="Default Home View"
            description={defaultView === 'paycheck' ? 'Group bills by paycheck' : 'Group bills by month'}
            rightContent={
              <Text style={{ color: theme.colors.primary }}>
                {defaultView === 'paycheck' ? 'Paycheck' : 'Month'}
              </Text>
            }
            onPress={() => setShowDefaultViewModal(true)}
          />
          <ListItem
            title="Currency"
            description="Set your preferred currency"
            rightContent={
              <Text style={{ color: theme.colors.primary }}>USD</Text>
            }
          />
        </View>
        
        <Divider style={styles.divider} />
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Data Management</Text>
          <ListItem
            title="Export Data"
            description="Export your financial data"
            onPress={() => console.log('Export data')}
          />
          <ListItem
            title="Import Data"
            description="Import financial data"
            onPress={() => console.log('Import data')}
          />
          <ListItem
            title="Clear All Data"
            description="Delete all app data"
            onPress={() => console.log('Clear data')}
          />
        </View>
        
        <Divider style={styles.divider} />
        
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>About</Text>
          <ListItem
            title="Version"
            rightContent={
              <Text>1.0.0</Text>
            }
          />
          <ListItem
            title="Terms of Service"
            onPress={() => console.log('Terms of Service')}
          />
          <ListItem
            title="Privacy Policy"
            onPress={() => console.log('Privacy Policy')}
          />
        </View>
      </ScrollView>
      
      {/* Notification Level Modal */}
      <Modal
        visible={showNotificationModal}
        onDismiss={() => setShowNotificationModal(false)}
        title="Notification Level"
        actions={[
          {
            label: 'Cancel',
            onPress: () => setShowNotificationModal(false),
            mode: 'text',
          },
        ]}
      >
        <List.Item
          title="Normal"
          description="Standard reminders for due bills and important events"
          onPress={() => handleNotificationLevelChange('normal')}
          left={props => (
            <List.Icon
              {...props}
              icon={notificationLevel === 'normal' ? 'radiobox-marked' : 'radiobox-blank'}
              color={theme.colors.primary}
            />
          )}
        />
        <List.Item
          title="Aggressive"
          description="Hourly reminders when bills are due until paid, with snooze options"
          onPress={() => handleNotificationLevelChange('aggressive')}
          left={props => (
            <List.Icon
              {...props}
              icon={notificationLevel === 'aggressive' ? 'radiobox-marked' : 'radiobox-blank'}
              color={theme.colors.primary}
            />
          )}
        />
      </Modal>
      
      {/* Default View Modal */}
      <Modal
        visible={showDefaultViewModal}
        onDismiss={() => setShowDefaultViewModal(false)}
        title="Default Home View"
        actions={[
          {
            label: 'Cancel',
            onPress: () => setShowDefaultViewModal(false),
            mode: 'text',
          },
        ]}
      >
        <List.Item
          title="Paycheck View"
          description="Group bills by paycheck"
          onPress={() => handleDefaultViewChange('paycheck')}
          left={props => (
            <List.Icon
              {...props}
              icon={defaultView === 'paycheck' ? 'radiobox-marked' : 'radiobox-blank'}
              color={theme.colors.primary}
            />
          )}
        />
        <List.Item
          title="Month View"
          description="Group bills by month"
          onPress={() => handleDefaultViewChange('month')}
          left={props => (
            <List.Icon
              {...props}
              icon={defaultView === 'month' ? 'radiobox-marked' : 'radiobox-blank'}
              color={theme.colors.primary}
            />
          )}
        />
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  divider: {
    height: 8,
  },
});

export default SettingsScreen;
