import React, { useState } from 'react';
import { StyleSheet, View, TouchableOpacity } from 'react-native';
import { Text, useTheme, TextInput as PaperTextInput } from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

interface TextInputProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'number-pad' | 'decimal-pad' | 'numeric' | 'email-address' | 'phone-pad';
  icon?: string;
  error?: string;
  multiline?: boolean;
  numberOfLines?: number;
  disabled?: boolean;
  right?: React.ReactNode;
}

const TextInput: React.FC<TextInputProps> = ({
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry = false,
  keyboardType = 'default',
  icon,
  error,
  multiline = false,
  numberOfLines = 1,
  disabled = false,
  right,
}) => {
  const theme = useTheme();
  const [isFocused, setIsFocused] = useState(false);
  
  return (
    <View style={styles.container}>
      <PaperTextInput
        label={label}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        mode="outlined"
        multiline={multiline}
        numberOfLines={multiline ? numberOfLines : undefined}
        disabled={disabled}
        error={!!error}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        left={icon ? (
          <PaperTextInput.Icon 
            icon={() => (
              <MaterialCommunityIcons 
                name={icon} 
                size={24} 
                color={
                  error 
                    ? theme.colors.error 
                    : isFocused 
                      ? theme.colors.primary 
                      : theme.colors.onSurfaceVariant
                } 
              />
            )} 
          />
        ) : undefined}
        right={right}
        style={styles.input}
        outlineStyle={{ borderRadius: theme.roundness }}
      />
      {error && (
        <Text variant="bodySmall" style={[styles.errorText, { color: theme.colors.error }]}>
          {error}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  input: {
    width: '100%',
  },
  errorText: {
    marginTop: 4,
    marginLeft: 12,
  },
});

export default TextInput;
