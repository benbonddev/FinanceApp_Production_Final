import AsyncStorage from '@react-native-async-storage/async-storage';

// Storage keys
export const STORAGE_KEYS = {
  BILLS: 'finance_app_bills',
  PAYCHECKS: 'finance_app_paychecks',
  BUDGETS: 'finance_app_budgets',
  DEBTS: 'finance_app_debts',
  GOALS: 'finance_app_goals',
  SETTINGS: 'finance_app_settings',
};

// Generic save data function
export const saveData = async (key: string, data: any): Promise<boolean> => {
  try {
    const jsonValue = JSON.stringify(data);
    await AsyncStorage.setItem(key, jsonValue);
    return true;
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to save data for key ${key}: ${error.message}`);
    } else {
      throw new Error(`Failed to save data for key ${key}`);
    }
  }
};

// Generic load data function
export const loadData = async <T>(key: string, defaultValue: T): Promise<T> => {
  try {
    const jsonValue = await AsyncStorage.getItem(key);
    if (jsonValue === null) {
      return defaultValue;
    }
    return JSON.parse(jsonValue) as T;
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to load data for key ${key}: ${error.message}`);
    } else {
      throw new Error(`Failed to load data for key ${key}`);
    }
  }
};

// Clear specific data
export const clearData = async (key: string): Promise<boolean> => {
  try {
    await AsyncStorage.removeItem(key);
    return true;
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to clear data for key ${key}: ${error.message}`);
    } else {
      throw new Error(`Failed to clear data for key ${key}`);
    }
  }
};

// Clear all app data
export const clearAllData = async (): Promise<boolean> => {
  try {
    const keys = Object.values(STORAGE_KEYS);
    await AsyncStorage.multiRemove(keys);
    return true;
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to clear all app data: ${error.message}`);
    } else {
      throw new Error('Failed to clear all app data');
    }
  }
};

// Export data to JSON string
export const exportData = async (): Promise<string | null> => {
  try {
    const exportObject: Record<string, any> = {};
    
    for (const key of Object.values(STORAGE_KEYS)) {
      const data = await AsyncStorage.getItem(key);
      if (data) {
        exportObject[key] = JSON.parse(data);
      }
    }
    
    return JSON.stringify(exportObject);
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to export data: ${error.message}`);
    } else {
      throw new Error('Failed to export data');
    }
  }
};

// Import data from JSON string
export const importData = async (jsonData: string): Promise<boolean> => {
  try {
    const importObject = JSON.parse(jsonData);
    
    for (const key of Object.keys(importObject)) {
      if (Object.values(STORAGE_KEYS).includes(key as any)) {
        await AsyncStorage.setItem(key, JSON.stringify(importObject[key]));
      }
    }
    
    return true;
  } catch (error) {
    // Use proper error handling instead of console.log
    if (error instanceof Error) {
      throw new Error(`Failed to import data: ${error.message}`);
    } else {
      throw new Error('Failed to import data');
    }
  }
};
