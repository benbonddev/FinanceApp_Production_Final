import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../index';
import { Bill } from '../../types';
import { saveData, loadData, STORAGE_KEYS } from '../../utils/storage';
import { isAfter, isBefore, addDays, parseISO } from 'date-fns';

// Sample bills for development
const initialBills: Bill[] = [
  {
    id: '1',
    name: 'Rent',
    amount: 1200,
    dueDate: new Date(2025, 3, 15).toISOString(),
    isPaid: false,
    category: 'Housing',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '2',
    name: 'Electricity',
    amount: 85,
    dueDate: new Date(2025, 3, 20).toISOString(),
    isPaid: false,
    category: 'Utilities',
    isRecurring: true,
    recurringFrequency: 'monthly',
    isDynamic: true,
  },
  {
    id: '3',
    name: 'Internet',
    amount: 65,
    dueDate: new Date(2025, 3, 22).toISOString(),
    isPaid: true,
    paidDate: new Date(2025, 3, 21).toISOString(),
    category: 'Utilities',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '4',
    name: 'Phone',
    amount: 45,
    dueDate: new Date(2025, 3, 18).toISOString(),
    isPaid: false,
    category: 'Utilities',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '5',
    name: 'Car Insurance',
    amount: 120,
    dueDate: new Date(2025, 3, 10).toISOString(),
    isPaid: true,
    paidDate: new Date(2025, 3, 9).toISOString(),
    category: 'Insurance',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '6',
    name: 'Gym Membership',
    amount: 50,
    dueDate: new Date(2025, 3, 5).toISOString(),
    isPaid: true,
    paidDate: new Date(2025, 3, 5).toISOString(),
    category: 'Health',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '7',
    name: 'Streaming Service',
    amount: 15,
    dueDate: new Date(2025, 3, 25).toISOString(),
    isPaid: false,
    category: 'Entertainment',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
  {
    id: '8',
    name: 'Credit Card Payment',
    amount: 200,
    dueDate: new Date(2025, 3, 28).toISOString(),
    isPaid: false,
    category: 'Debt',
    isRecurring: true,
    recurringFrequency: 'monthly',
  },
];

interface BillsState {
  bills: Bill[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: BillsState = {
  bills: [],
  status: 'idle',
  error: null,
};

export const billsSlice = createSlice({
  name: 'bills',
  initialState,
  reducers: {
    setBills: (state, action: PayloadAction<Bill[]>) => {
      state.bills = action.payload;
      state.status = 'succeeded';
      // Persist to storage
      saveData(STORAGE_KEYS.BILLS, action.payload);
    },
    addBill: (state, action: PayloadAction<Bill>) => {
      state.bills.push(action.payload);
      // Persist to storage
      saveData(STORAGE_KEYS.BILLS, state.bills);
    },
    updateBill: (state, action: PayloadAction<Bill>) => {
      const index = state.bills.findIndex(bill => bill.id === action.payload.id);
      if (index !== -1) {
        state.bills[index] = action.payload;
        // Persist to storage
        saveData(STORAGE_KEYS.BILLS, state.bills);
      }
    },
    deleteBill: (state, action: PayloadAction<string>) => {
      state.bills = state.bills.filter(bill => bill.id !== action.payload);
      // Persist to storage
      saveData(STORAGE_KEYS.BILLS, state.bills);
    },
    payBill: (state, action: PayloadAction<{ id: string, paidDate: string }>) => {
      const index = state.bills.findIndex(bill => bill.id === action.payload.id);
      if (index !== -1) {
        state.bills[index].isPaid = true;
        state.bills[index].paidDate = action.payload.paidDate;
        // Persist to storage
        saveData(STORAGE_KEYS.BILLS, state.bills);
      }
    },
    unpayBill: (state, action: PayloadAction<string>) => {
      const index = state.bills.findIndex(bill => bill.id === action.payload);
      if (index !== -1) {
        state.bills[index].isPaid = false;
        delete state.bills[index].paidDate;
        // Persist to storage
        saveData(STORAGE_KEYS.BILLS, state.bills);
      }
    },
    loadSampleBills: (state) => {
      state.bills = initialBills;
      state.status = 'succeeded';
      // Persist to storage
      saveData(STORAGE_KEYS.BILLS, initialBills);
    },
    loadBillsFromStorage: (state) => {
      state.status = 'loading';
    },
    loadBillsSuccess: (state, action: PayloadAction<Bill[]>) => {
      state.bills = action.payload;
      state.status = 'succeeded';
    },
    loadBillsFailure: (state, action: PayloadAction<string>) => {
      state.error = action.payload;
      state.status = 'failed';
    },
  },
});

export const { 
  setBills, 
  addBill, 
  updateBill, 
  deleteBill, 
  payBill, 
  unpayBill, 
  loadSampleBills,
  loadBillsFromStorage,
  loadBillsSuccess,
  loadBillsFailure
} = billsSlice.actions;

// Thunk to load bills from storage
export const loadBillsAsync = () => async (dispatch: any) => {
  dispatch(loadBillsFromStorage());
  try {
    const bills = await loadData<Bill[]>(STORAGE_KEYS.BILLS, []);
    dispatch(loadBillsSuccess(bills && bills.length > 0 ? bills : initialBills));
  } catch (error) {
    dispatch(loadBillsFailure(error instanceof Error ? error.message : 'Unknown error'));
    dispatch(loadBillsSuccess(initialBills)); // Fallback to sample data
  }
};

// Selectors
export const selectAllBills = (state: RootState) => state.bills.bills || [];
export const selectBillById = (state: RootState, billId: string | undefined) => 
  billId ? state.bills.bills.find(bill => bill.id === billId) : undefined;
export const selectBillsStatus = (state: RootState) => state.bills.status;
export const selectBillsError = (state: RootState) => state.bills.error;

// Selector for upcoming bills with proper null safety
export const selectUpcomingBills = (state: RootState) => {
  const today = new Date();
  const nextWeek = addDays(today, 7);
  
  return (state.bills.bills || []).filter(bill => {
    if (!bill || !bill.dueDate) return false;
    try {
      const dueDate = parseISO(bill.dueDate);
      return !bill.isPaid && isAfter(dueDate, today) && isBefore(dueDate, nextWeek);
    } catch (error) {
      return false;
    }
  }).sort((a, b) => {
    try {
      return parseISO(a.dueDate).getTime() - parseISO(b.dueDate).getTime();
    } catch (error) {
      return 0;
    }
  });
};

// Selector for bills by paycheck
export const selectBillsByPaycheck = (state: RootState, paycheckId: string | undefined) => {
  if (!paycheckId) return [];
  return (state.bills.bills || []).filter(bill => bill.payPeriodId === paycheckId);
};

// Selector for bills by category
export const selectBillsByCategory = (state: RootState, category: string | undefined) => {
  if (!category) return [];
  return (state.bills.bills || []).filter(bill => bill.category === category);
};

export default billsSlice.reducer;
