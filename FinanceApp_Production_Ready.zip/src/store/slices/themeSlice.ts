import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../index';
import { saveData, loadData, STORAGE_KEYS } from '../../utils/storage';

interface ThemeState {
  isDarkMode: boolean;
}

const initialState: ThemeState = {
  isDarkMode: false,
};

export const themeSlice = createSlice({
  name: 'theme',
  initialState,
  reducers: {
    toggleTheme: (state) => {
      state.isDarkMode = !state.isDarkMode;
      // Persist to storage
      saveData(STORAGE_KEYS.SETTINGS, { isDarkMode: state.isDarkMode });
    },
    setDarkMode: (state, action: PayloadAction<boolean>) => {
      state.isDarkMode = action.payload;
      // Persist to storage
      saveData(STORAGE_KEYS.SETTINGS, { isDarkMode: state.isDarkMode });
    },
    loadThemeFromStorage: (state) => {
      // This is a placeholder for the thunk action
    },
    loadThemeSuccess: (state, action: PayloadAction<boolean>) => {
      state.isDarkMode = action.payload;
    },
  },
});

export const { 
  toggleTheme, 
  setDarkMode,
  loadThemeFromStorage,
  loadThemeSuccess
} = themeSlice.actions;

// Thunk to load theme settings from storage
export const loadThemeAsync = () => async (dispatch: any) => {
  dispatch(loadThemeFromStorage());
  try {
    const settings = await loadData<{ isDarkMode: boolean }>(STORAGE_KEYS.SETTINGS, { isDarkMode: false });
    dispatch(loadThemeSuccess(settings.isDarkMode));
  } catch (error) {
    console.error('Error loading theme settings:', error);
    // Default to false if there's an error
    dispatch(loadThemeSuccess(false));
  }
};

export const selectIsDarkMode = (state: RootState) => state.theme.isDarkMode;

export default themeSlice.reducer;
