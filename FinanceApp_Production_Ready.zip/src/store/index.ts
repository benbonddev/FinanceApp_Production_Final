import { configureStore } from '@reduxjs/toolkit';
import themeReducer from './slices/themeSlice';
import billsReducer from './slices/billsSlice';
import paychecksReducer from './slices/paychecksSlice';
import budgetsReducer from './slices/budgetSlice';
import debtsReducer from './slices/debtSlice';

export const store = configureStore({
  reducer: {
    theme: themeReducer,
    bills: billsReducer,
    paychecks: paychecksReducer,
    budgets: budgetsReducer,
    debts: debtsReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Enable serializable check for production
        warnAfter: 128,
        ignoredActions: ['persist/PERSIST'],
        ignoredActionPaths: ['meta.arg', 'payload.timestamp'],
        ignoredPaths: ['items.dates'],
      },
    }),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
