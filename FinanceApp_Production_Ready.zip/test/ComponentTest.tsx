import React, { useState } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Text, useTheme, Button } from 'react-native-paper';
import TextInput from '../src/components/Form/TextInput';

const ComponentTest: React.FC = () => {
  const theme = useTheme();
  const [text1, setText1] = useState('');
  const [text2, setText2] = useState('');
  const [text3, setText3] = useState('');
  const [text4, setText4] = useState('');
  
  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Text style={[styles.title, { color: theme.colors.text }]}>Component Test</Text>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>TextInput Icon Tests</Text>
        
        <TextInput
          label="Using icon prop (legacy)"
          value={text1}
          onChangeText={setText1}
          placeholder="This uses the icon prop"
          icon="account"
        />
        
        <TextInput
          label="Using leftIcon prop"
          value={text2}
          onChangeText={setText2}
          placeholder="This uses the leftIcon prop"
          leftIcon="currency-usd"
        />
        
        <TextInput
          label="Using rightIcon prop"
          value={text3}
          onChangeText={setText3}
          placeholder="This uses the rightIcon prop"
          rightIcon="calendar"
        />
        
        <TextInput
          label="Using both leftIcon and rightIcon"
          value={text4}
          onChangeText={setText4}
          placeholder="This uses both icon props"
          leftIcon="email"
          rightIcon="send"
        />
      </View>
      
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Theme Color Tests</Text>
        
        <View style={styles.colorBox}>
          <Text style={styles.colorLabel}>Primary</Text>
          <View style={[styles.colorSample, { backgroundColor: theme.colors.primary }]} />
        </View>
        
        <View style={styles.colorBox}>
          <Text style={styles.colorLabel}>Surface</Text>
          <View style={[styles.colorSample, { backgroundColor: theme.colors.surface }]} />
        </View>
        
        <View style={styles.colorBox}>
          <Text style={styles.colorLabel}>Border</Text>
          <View style={[styles.colorSample, { backgroundColor: theme.colors.border }]} />
        </View>
        
        <View style={styles.colorBox}>
          <Text style={styles.colorLabel}>Outline</Text>
          <View style={[styles.colorSample, { backgroundColor: theme.colors.outline }]} />
        </View>
        
        <View style={styles.colorBox}>
          <Text style={styles.colorLabel}>onSurfaceVariant</Text>
          <View style={[styles.colorSample, { backgroundColor: theme.colors.onSurfaceVariant }]} />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  colorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  colorLabel: {
    width: 120,
    fontSize: 14,
  },
  colorSample: {
    width: 24,
    height: 24,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#ccc',
  },
});

export default ComponentTest;
