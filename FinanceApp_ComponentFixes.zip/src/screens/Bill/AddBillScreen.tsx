import React, { useState } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Text, useTheme, Button, TextInput as PaperTextInput } from 'react-native-paper';
import { useAppSelector, useAppDispatch } from '../../hooks/reduxHooks';
import { addBill } from '../../store/slices/billsSlice';
import { selectAllPaychecks } from '../../store/slices/paychecksSlice';
import TextInput from '../../components/Form/TextInput';
import DatePicker from '../../components/Form/DatePicker';
import Dropdown from '../../components/Form/Dropdown';
import SwitchInput from '../../components/Form/SwitchInput';
import { Bill } from '../../types';
import { format, parseISO } from 'date-fns';

const AddBillScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  const paychecks = useAppSelector(selectAllPaychecks);
  
  // Form state
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(new Date());
  const [category, setCategory] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringFrequency, setRecurringFrequency] = useState<'weekly' | 'biweekly' | 'monthly' | 'quarterly' | 'yearly'>('monthly');
  const [notes, setNotes] = useState('');
  const [isDynamic, setIsDynamic] = useState(false);
  const [payPeriodId, setPayPeriodId] = useState('');
  
  // Validation state
  const [errors, setErrors] = useState({
    name: '',
    amount: '',
    category: '',
  });
  
  // Handle save
  const handleSave = () => {
    // Validate form
    const newErrors = {
      name: name.trim() === '' ? 'Bill name is required' : '',
      amount: amount.trim() === '' || isNaN(parseFloat(amount)) ? 'Valid amount is required' : '',
      category: category.trim() === '' ? 'Category is required' : '',
    };
    
    setErrors(newErrors);
    
    // Check if there are any errors
    if (Object.values(newErrors).some(error => error !== '')) {
      return;
    }
    
    // Create new bill
    const newBill: Bill = {
      id: Date.now().toString(), // Simple ID generation for demo
      name,
      amount: parseFloat(amount),
      dueDate: dueDate.toISOString(),
      isPaid: false,
      isRecurring,
      recurringFrequency: isRecurring ? recurringFrequency : undefined,
      category,
      notes: notes.trim() !== '' ? notes : undefined,
      isDynamic,
      payPeriodId: payPeriodId !== '' ? payPeriodId : undefined,
    };
    
    dispatch(addBill(newBill));
    navigation.goBack();
  };
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: theme.colors.background }]}
      contentContainerStyle={styles.contentContainer}
    >
      <Text style={[styles.title, { color: theme.colors.text }]}>Add New Bill</Text>
      
      <TextInput
        label="Bill Name"
        value={name}
        onChangeText={setName}
        placeholder="Enter bill name"
        error={errors.name}
      />
      
      <TextInput
        label="Amount"
        value={amount}
        onChangeText={setAmount}
        placeholder="Enter amount"
        keyboardType="numeric"
        leftIcon="currency-usd"
        error={errors.amount}
      />
      
      <DatePicker
        label="Due Date"
        value={dueDate}
        onChange={setDueDate}
      />
      
      <TextInput
        label="Category"
        value={category}
        onChangeText={setCategory}
        placeholder="Enter category (e.g., Housing, Utilities)"
        error={errors.category}
      />
      
      <SwitchInput
        label="Recurring Bill"
        value={isRecurring}
        onValueChange={setIsRecurring}
        description="This bill repeats on a regular schedule"
      />
      
      {isRecurring && (
        <Dropdown
          label="Frequency"
          value={recurringFrequency}
          options={[
            { label: 'Weekly', value: 'weekly' },
            { label: 'Bi-weekly', value: 'biweekly' },
            { label: 'Monthly', value: 'monthly' },
            { label: 'Quarterly', value: 'quarterly' },
            { label: 'Yearly', value: 'yearly' },
          ]}
          onSelect={(option) => setRecurringFrequency(option.value as any)}
        />
      )}
      
      <SwitchInput
        label="Dynamic Amount"
        value={isDynamic}
        onValueChange={setIsDynamic}
        description="Bill amount varies each period (like utilities)"
      />
      
      <Dropdown
        label="Assign to Paycheck"
        value={payPeriodId}
        options={paychecks.map(paycheck => ({
          label: `${paycheck.name} - ${format(parseISO(paycheck.date), 'MMM d, yyyy')}`,
          value: paycheck.id,
        }))}
        onSelect={(option) => setPayPeriodId(option.value as string)}
        placeholder="Select a paycheck"
      />
      
      <TextInput
        label="Notes"
        value={notes}
        onChangeText={setNotes}
        placeholder="Add notes (optional)"
        multiline
        numberOfLines={3}
      />
      
      <View style={styles.actions}>
        <Button
          mode="outlined"
          onPress={() => navigation.goBack()}
          style={styles.button}
        >
          Cancel
        </Button>
        <Button
          mode="contained"
          onPress={handleSave}
          style={styles.button}
        >
          Save
        </Button>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
  },
});

export default AddBillScreen;
