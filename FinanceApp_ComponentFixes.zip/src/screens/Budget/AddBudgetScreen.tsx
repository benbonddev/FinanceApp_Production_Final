import React, { useState } from 'react';
import { StyleSheet, View, ScrollView } from 'react-native';
import { Text, useTheme, Button } from 'react-native-paper';
import { useAppSelector, useAppDispatch } from '../../hooks/reduxHooks';
import TextInput from '../../components/Form/TextInput';
import Dropdown from '../../components/Form/Dropdown';
import SwitchInput from '../../components/Form/SwitchInput';
import { Budget } from '../../types';
import { addBudget } from '../../store/slices/budgetSlice';

const AddBudgetScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  
  // Form state
  const [category, setCategory] = useState('');
  const [limit, setLimit] = useState('');
  const [period, setPeriod] = useState<'monthly' | 'paycheck'>('monthly');
  const [notes, setNotes] = useState('');
  const [rollover, setRollover] = useState(false);
  
  // Validation state
  const [errors, setErrors] = useState({
    category: '',
    limit: '',
  });
  
  // Predefined categories
  const categories = [
    { label: 'Housing', value: 'Housing' },
    { label: 'Utilities', value: 'Utilities' },
    { label: 'Food', value: 'Food' },
    { label: 'Transportation', value: 'Transportation' },
    { label: 'Entertainment', value: 'Entertainment' },
    { label: 'Health', value: 'Health' },
    { label: 'Shopping', value: 'Shopping' },
    { label: 'Personal', value: 'Personal' },
    { label: 'Education', value: 'Education' },
    { label: 'Savings', value: 'Savings' },
    { label: 'Debt', value: 'Debt' },
    { label: 'Other', value: 'Other' },
  ];
  
  // Handle save
  const handleSave = () => {
    // Validate form
    const newErrors = {
      category: category.trim() === '' ? 'Category is required' : '',
      limit: limit.trim() === '' || isNaN(parseFloat(limit)) ? 'Valid limit is required' : '',
    };
    
    setErrors(newErrors);
    
    // Check if there are any errors
    if (Object.values(newErrors).some(error => error !== '')) {
      return;
    }
    
    // Create new budget
    const newBudget: Budget = {
      id: Date.now().toString(), // Simple ID generation for demo
      category,
      limit: parseFloat(limit),
      spent: 0, // Start with zero spent
      period,
      notes: notes.trim() !== '' ? notes : undefined,
    };
    
    // Dispatch action to add the budget
    dispatch(addBudget(newBudget));
    
    navigation.goBack();
  };
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: theme.colors.background }]}
      contentContainerStyle={styles.contentContainer}
    >
      <Text style={[styles.title, { color: theme.colors.text }]}>Add New Budget</Text>
      
      <Dropdown
        label="Category"
        value={category}
        options={categories}
        onSelect={(option) => setCategory(option.value as string)}
        placeholder="Select a category"
        error={errors.category}
      />
      
      <TextInput
        label="Budget Limit"
        value={limit}
        onChangeText={setLimit}
        placeholder="Enter budget limit"
        keyboardType="numeric"
        leftIcon="currency-usd"
        error={errors.limit}
      />
      
      <Dropdown
        label="Budget Period"
        value={period}
        options={[
          { label: 'Monthly', value: 'monthly' },
          { label: 'Per Paycheck', value: 'paycheck' },
        ]}
        onSelect={(option) => setPeriod(option.value as 'monthly' | 'paycheck')}
      />
      
      <SwitchInput
        label="Rollover Unused Budget"
        value={rollover}
        onValueChange={setRollover}
        description="Unused budget will roll over to the next period"
      />
      
      <TextInput
        label="Notes"
        value={notes}
        onChangeText={setNotes}
        placeholder="Add notes (optional)"
        multiline
        numberOfLines={3}
      />
      
      <View style={styles.actions}>
        <Button
          mode="outlined"
          onPress={() => navigation.goBack()}
          style={styles.button}
        >
          Cancel
        </Button>
        <Button
          mode="contained"
          onPress={handleSave}
          style={styles.button}
        >
          Save
        </Button>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
  },
});

export default AddBudgetScreen;
