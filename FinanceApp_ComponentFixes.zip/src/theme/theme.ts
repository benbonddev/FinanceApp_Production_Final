import { DefaultTheme, DarkTheme as PaperDarkTheme } from 'react-native-paper';
import { DarkTheme as NavigationDarkTheme, DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import { CustomTheme } from '../types';

// Create custom light theme with proper type extension
export const lightTheme: CustomTheme = {
  ...NavigationDefaultTheme,
  ...DefaultTheme,
  colors: {
    ...NavigationDefaultTheme.colors,
    ...DefaultTheme.colors,
    primary: '#6200ee',
    accent: '#03dac4',
    background: '#f6f6f6',
    surface: '#ffffff',
    text: '#000000',
    error: '#B00020',
    success: '#4CAF50', // Custom color for success states
    warning: '#FFC107', // Custom color for warning states
    notification: '#f50057',
    card: '#ffffff',
    border: '#e0e0e0',
    outline: '#757575', // Added for consistent theme usage
    onSurfaceVariant: '#757575', // Added for consistent theme usage
  },
  roundness: 8,
  animation: {
    scale: 1.0,
  },
};

// Create custom dark theme with proper type extension
export const darkTheme: CustomTheme = {
  ...NavigationDarkTheme,
  ...PaperDarkTheme,
  colors: {
    ...NavigationDarkTheme.colors,
    ...PaperDarkTheme.colors,
    primary: '#BB86FC',
    accent: '#03dac4',
    background: '#121212',
    surface: '#1e1e1e',
    text: '#ffffff',
    error: '#CF6679',
    success: '#4CAF50', // Custom color for success states
    warning: '#FFC107', // Custom color for warning states
    notification: '#f50057',
    card: '#1e1e1e',
    border: '#2c2c2c',
    outline: '#9e9e9e', // Added for consistent theme usage
    onSurfaceVariant: '#bbbbbb', // Added for consistent theme usage
  },
  roundness: 8,
  animation: {
    scale: 1.0,
  },
};
