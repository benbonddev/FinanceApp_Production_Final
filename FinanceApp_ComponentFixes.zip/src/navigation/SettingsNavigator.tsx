import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import SettingsScreen from '../screens/Settings/SettingsScreen';
import ThemePreviewScreen from '../screens/Settings/ThemePreviewScreen';
import NotificationsScreen from '../screens/Notifications/NotificationsScreen';
import PaymentHistoryScreen from '../screens/Payment/PaymentHistoryScreen';
import DashboardScreen from '../screens/Dashboard/DashboardScreen';

const Stack = createStackNavigator();

const SettingsNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="SettingsScreen"
      screenOptions={{
        headerShown: true,
      }}
    >
      <Stack.Screen 
        name="SettingsScreen" 
        component={SettingsScreen} 
        options={{ title: 'Settings' }}
      />
      <Stack.Screen 
        name="ThemePreview" 
        component={ThemePreviewScreen} 
        options={{ title: 'Theme Preview' }}
      />
      <Stack.Screen 
        name="Notifications" 
        component={NotificationsScreen} 
        options={{ title: 'Notifications' }}
      />
      <Stack.Screen 
        name="PaymentHistory" 
        component={PaymentHistoryScreen} 
        options={{ title: 'Payment History' }}
      />
      <Stack.Screen 
        name="Dashboard" 
        component={DashboardScreen} 
        options={{ title: 'Financial Dashboard' }}
      />
    </Stack.Navigator>
  );
};

export default SettingsNavigator;
