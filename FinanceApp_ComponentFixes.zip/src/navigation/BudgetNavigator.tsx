import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import BudgetScreen from '../screens/Budget/BudgetScreen';
import AddBudgetScreen from '../screens/Budget/AddBudgetScreen';

const Stack = createStackNavigator();

const BudgetNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="BudgetScreen"
      screenOptions={{
        headerShown: true,
      }}
    >
      <Stack.Screen 
        name="BudgetScreen" 
        component={BudgetScreen} 
        options={{ title: 'Budget' }}
      />
      <Stack.Screen 
        name="AddBudget" 
        component={AddBudgetScreen} 
        options={{ title: 'Add Budget Category' }}
      />
    </Stack.Navigator>
  );
};

export default BudgetNavigator;
