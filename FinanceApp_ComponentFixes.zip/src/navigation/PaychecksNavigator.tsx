import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import PaychecksScreen from '../screens/Paychecks/PaychecksScreen';
import AddPaycheckScreen from '../screens/Paychecks/AddPaycheckScreen';

const Stack = createStackNavigator();

const PaychecksNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="PaychecksScreen"
      screenOptions={{
        headerShown: true,
      }}
    >
      <Stack.Screen 
        name="PaychecksScreen" 
        component={PaychecksScreen} 
        options={{ title: 'Paychecks' }}
      />
      <Stack.Screen 
        name="AddPaycheck" 
        component={AddPaycheckScreen} 
        options={{ title: 'Add Paycheck' }}
      />
    </Stack.Navigator>
  );
};

export default PaychecksNavigator;
