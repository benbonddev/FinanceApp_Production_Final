# Financial App - User Guide

## Introduction

Welcome to the Financial App, your comprehensive solution for managing personal finances. This guide will walk you through all the features and functionality of the application.

## Getting Started

### Home Screen

The Home screen is your central hub for managing bills and financial obligations.

#### Due Bills Tab

- **Default View**: Shows all upcoming bills in a clean, modern layout
- **View Toggle**: Use the pills at the top to switch between paycheck view and month view
- **Paycheck Grouping**: In paycheck view, bills are grouped under the paycheck they fall into based on due date
- **Summary Information**: Each paycheck group shows a summary (bills due, paid, total amount, remaining)
- **Controls**: Tap the gear icon to toggle visibility of summary statistics

#### Adding a Bill

1. Tap the "+" button at the bottom right of the screen
2. Fill in the bill details:
   - Name
   - Amount
   - Due date
   - Category
   - Recurring options (if applicable)
   - Notes (optional)
3. Tap "Save" to add the bill

#### Bill Interactions

- **View Details**: Tap on a bill name to open detailed information
- **Quick Actions**: Long press on a bill to see options:
  - Edit: Modify bill details
  - Pay Now: Mark the bill as paid
  - Pay Later: Reschedule the bill to the next paycheck

### Month View

The Month view provides a monthly overview of your bills and finances.

- **Monthly Summary**: View total bills, paid, unpaid, paychecks, and paycheck total
- **Bill Grouping**: Bills are grouped by paycheck within the month
- **Navigation**: Use the arrows at the top to navigate between months
- **Statistics Control**: Toggle visibility of statistics using the data sheet UI

### Paychecks

The Paychecks tab helps you manage your income sources.

- **Monthly Overview**: See your total income for the month
- **Paycheck List**: View all paychecks with dates and amounts
- **Paycheck Details**: Tap on a paycheck to see associated bills
- **Add Paycheck**: Use the "+" button to add a new income source

### Budget

The Budget tab helps you track and manage your spending by category.

- **Monthly Overview**: See income, expenses, and balance
- **Category Breakdown**: Visual representation of spending by category
- **Budget Details**: Individual budget cards showing progress for each category
- **Add Budget**: Create new budget categories with spending limits

### Debt Repayment

The Debt Repayment tab helps you track and pay off debts.

- **Debt Overview**: See total debt, paid amount, and monthly payment
- **Payoff Projections**: View estimated payoff date and total interest
- **Strategy Selection**: Choose between Avalanche (highest interest first) or Snowball (smallest balance first)
- **Debt List**: View all debts with progress indicators
- **Add Debt**: Add new debts with details like interest rate and minimum payment

### Goals

The Goals tab helps you set and track financial goals.

- **Goals Overview**: See overall progress toward all goals
- **Goal Filtering**: Filter goals by All, Active, or Completed
- **Goal Details**: Each goal shows progress, target date, and monthly contribution needed
- **Add Goal**: Create new savings goals with target amounts and dates

### Notifications

The Notifications screen shows alerts for bills and financial events.

- **Due Bills**: Get notifications for upcoming and overdue bills
- **Action Buttons**: Pay Now or snooze notifications
- **Snooze Options**: Choose from 3 hours, 12 hours, or 1 day

### Settings

The Settings screen allows you to customize the app.

- **Appearance**: Toggle between light and dark mode
- **Notifications**: Set notification level (normal or aggressive)
- **App Settings**: Configure default views and currency
- **Data Management**: Export or import financial data

### Payment History

The Payment History screen tracks your bill payments.

- **Monthly View**: See payment progress for each month
- **Payment Filtering**: Filter by All, Paid, or Unpaid
- **Payment Details**: View payment status and dates for each bill

### Dashboard

The Dashboard provides insights into your financial health.

- **Financial Health**: View savings rate and bill payment rate
- **Expense Breakdown**: See spending by category
- **Income vs Expenses**: Track 6-month trends
- **Financial Insights**: Get personalized recommendations

## Tips and Tricks

1. **Long Press Actions**: Long press on items throughout the app to access context-specific actions
2. **Swipe Navigation**: Swipe between tabs for quick navigation
3. **Dark Mode**: Toggle dark mode in settings for comfortable nighttime use
4. **Data Backup**: Use the export function in settings to back up your financial data
5. **Bill Scheduling**: Assign bills to specific paychecks for better planning

## Troubleshooting

- **App Performance**: If the app seems slow, try clearing the cache in settings
- **Missing Data**: If data appears missing, check your filters and date ranges
- **Notification Issues**: Ensure notifications are enabled in both app settings and device settings
- **Sync Problems**: Use the refresh button on screens to manually sync data

## Support

For additional help or to report issues, use the Help section in the app settings.
